
import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import HomePage from './pages/HomePage'
import PlanetPage from './pages/PlanetPage'
import AllPlanetsPage from './pages/AllPlanetsPage'
import StudyModePage from './pages/StudyModePage'

function App() {
  return (
    <>
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: { 
            background: 'rgba(255, 255, 255, 0.1)', 
            color: '#fff',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(255, 255, 255, 0.2)'
          },
          success: { style: { background: 'rgba(16, 185, 129, 0.2)' } },
          error: { style: { background: 'rgba(239, 68, 68, 0.2)' } }
        }}
      />
      
      <Router>
        <div className="min-h-screen bg-black text-white overflow-x-hidden">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/planeta/:planetName" element={<PlanetPage />} />
            <Route path="/todos-planetas" element={<AllPlanetsPage />} />
            <Route path="/modo-estudo" element={<StudyModePage />} />
          </Routes>
        </div>
      </Router>
    </>
  )
}

export default App
