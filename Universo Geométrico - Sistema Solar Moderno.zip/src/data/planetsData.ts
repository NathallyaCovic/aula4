
export interface Planet {
  name: string
  image: string
  description: string
  diameter: string
  distanceFromSun: string
  moons: number
  rotationPeriod: string
  orbitalPeriod: string
  gravity: string
  atmosphere: string
  temperature: string
  color: string
  facts: string[]
  composition: string
  discoveryDate?: string
  namedAfter: string
}

export const planetsData: Planet[] = [
  {
    name: 'Mercúrio',
    image: 'https://images.pexels.com/photos/87009/earth-soil-creep-moon-87009.jpeg?auto=compress&cs=tinysrgb&w=800',
    description: 'O planeta mais próximo do Sol, Mercúrio é um mundo extremo de temperaturas contrastantes.',
    diameter: '4.879 km',
    distanceFromSun: '57,9 milhões km',
    moons: 0,
    rotationPeriod: '58,6 dias terrestres',
    orbitalPeriod: '88 dias terrestres',
    gravity: '3,7 m/s²',
    atmosphere: 'Praticamente inexistente',
    temperature: '-173°C a 427°C',
    color: '#8C7853',
    composition: 'Núcleo de ferro, manto rochoso',
    namedAfter: 'Mensageiro dos deuses romanos',
    facts: [
      'Um dia em Mercúrio dura mais que um ano mercuriano',
      'Tem crateras que nunca veem a luz do Sol',
      'Não possui atmosfera significativa para reter calor',
      'É o menor planeta do Sistema Solar',
      'Tem variações de temperatura extremas'
    ]
  },
  {
    name: 'Vênus',
    image: 'https://images.pexels.com/photos/33684/earth-planet-world-globe.jpg?auto=compress&cs=tinysrgb&w=800',
    description: 'Conhecido como "Estrela da Manhã", Vênus é o planeta mais quente do Sistema Solar.',
    diameter: '12.104 km',
    distanceFromSun: '108,2 milhões km',
    moons: 0,
    rotationPeriod: '243 dias terrestres',
    orbitalPeriod: '225 dias terrestres',
    gravity: '8,87 m/s²',
    atmosphere: '96% dióxido de carbono',
    temperature: '462°C (constante)',
    color: '#FFC649',
    composition: 'Núcleo de ferro-níquel, manto rochoso',
    namedAfter: 'Deusa romana do amor e beleza',
    facts: [
      'Gira no sentido contrário aos outros planetas',
      'Tem pressão atmosférica 90 vezes maior que a Terra',
      'É o planeta mais brilhante no céu noturno',
      'Chuvas de ácido sulfúrico caem em sua atmosfera',
      'Um dia venusiano é mais longo que um ano venusiano'
    ]
  },
  {
    name: 'Terra',
    image: 'https://images.pexels.com/photos/414171/pexels-photo-414171.jpeg?auto=compress&cs=tinysrgb&w=800',
    description: 'Nosso planeta azul, o único conhecido por abrigar vida no universo.',
    diameter: '12.756 km',
    distanceFromSun: '149,6 milhões km',
    moons: 1,
    rotationPeriod: '24 horas',
    orbitalPeriod: '365,25 dias',
    gravity: '9,8 m/s²',
    atmosphere: '78% nitrogênio, 21% oxigênio',
    temperature: '-89°C a 58°C',
    color: '#6B93D6',
    composition: 'Núcleo de ferro-níquel, manto rochoso, crosta continental e oceânica',
    namedAfter: 'Do inglês antigo "ertha" (solo)',
    facts: [
      'É o único planeta conhecido com vida',
      '71% da superfície é coberta por água',
      'Tem um campo magnético que nos protege da radiação solar',
      'A Lua influencia as marés oceânicas',
      'Possui placas tectônicas ativas'
    ]
  },
  {
    name: 'Marte',
    image: 'https://images.pexels.com/photos/73910/mars-mars-rover-space-travel-planet-73910.jpeg?auto=compress&cs=tinysrgb&w=800',
    description: 'O "Planeta Vermelho" é nosso vizinho mais próximo e alvo de futuras missões tripuladas.',
    diameter: '6.792 km',
    distanceFromSun: '227,9 milhões km',
    moons: 2,
    rotationPeriod: '24,6 horas',
    orbitalPeriod: '687 dias terrestres',
    gravity: '3,71 m/s²',
    atmosphere: '95% dióxido de carbono',
    temperature: '-87°C a -5°C',
    color: '#CD5C5C',
    composition: 'Núcleo de ferro, manto rochoso rico em ferro',
    namedAfter: 'Deus romano da guerra',
    facts: [
      'Tem o maior vulcão do Sistema Solar (Monte Olimpo)',
      'Evidências sugerem que já teve água líquida',
      'Tempestades de poeira podem cobrir todo o planeta',
      'Suas luas são provavelmente asteroides capturados',
      'Um dia marciano dura quase o mesmo que um dia terrestre'
    ]
  },
  {
    name: 'Júpiter',
    image: 'https://images.pexels.com/photos/39561/solar-system-emergence-spitzer-telescope-39561.jpeg?auto=compress&cs=tinysrgb&w=800',
    description: 'O gigante gasoso do Sistema Solar, Júpiter protege os planetas internos de asteroides.',
    diameter: '142.984 km',
    distanceFromSun: '778,5 milhões km',
    moons: 95,
    rotationPeriod: '9,9 horas',
    orbitalPeriod: '11,9 anos terrestres',
    gravity: '24,79 m/s²',
    atmosphere: '89% hidrogênio, 10% hélio',
    temperature: '-108°C (topo das nuvens)',
    color: '#D8CA9D',
    composition: 'Principalmente hidrogênio e hélio',
    namedAfter: 'Rei dos deuses romanos',
    facts: [
      'É maior que todos os outros planetas combinados',
      'Tem uma tempestade (Grande Mancha Vermelha) maior que a Terra',
      'Atua como um "aspirador de poeira cósmica"',
      'Tem mais de 95 luas conhecidas',
      'Poderia ter se tornado uma estrela se fosse maior'
    ]
  },
  {
    name: 'Saturno',
    image: 'https://images.pexels.com/photos/87651/earth-blue-planet-globe-planet-87651.jpeg?auto=compress&cs=tinysrgb&w=800',
    description: 'Famoso por seus espetaculares anéis, Saturno é o segundo maior planeta do Sistema Solar.',
    diameter: '120.536 km',
    distanceFromSun: '1,432 bilhão km',
    moons: 146,
    rotationPeriod: '10,7 horas',
    orbitalPeriod: '29,4 anos terrestres',
    gravity: '10,44 m/s²',
    atmosphere: '96% hidrogênio, 3% hélio',
    temperature: '-139°C (topo das nuvens)',
    color: '#FAD5A5',
    composition: 'Principalmente hidrogênio e hélio',
    namedAfter: 'Deus romano da agricultura',
    facts: [
      'Seus anéis são feitos principalmente de gelo',
      'É menos denso que a água - flutuaria!',
      'Tem hexágonos perfeitos em seu polo norte',
      'Titã, sua maior lua, tem lagos de metano',
      'Seus anéis têm apenas alguns metros de espessura'
    ]
  },
  {
    name: 'Urano',
    image: 'https://images.pexels.com/photos/2156/sky-earth-space-working.jpg?auto=compress&cs=tinysrgb&w=800',
    description: 'O gigante de gelo que gira de lado, Urano é o planeta mais frio do Sistema Solar.',
    diameter: '51.118 km',
    distanceFromSun: '2,867 bilhões km',
    moons: 27,
    rotationPeriod: '17,2 horas',
    orbitalPeriod: '84 anos terrestres',
    gravity: '8,69 m/s²',
    atmosphere: '83% hidrogênio, 15% hélio, 2% metano',
    temperature: '-197°C',
    color: '#4FD0E7',
    composition: 'Água, metano e amônia gelados',
    namedAfter: 'Deus grego do céu',
    facts: [
      'Gira de lado - seu eixo está inclinado 98 graus',
      'Foi o primeiro planeta descoberto com telescópio',
      'Tem anéis verticais em vez de horizontais',
      'Um ano uraniano dura 84 anos terrestres',
      'Sua cor azul vem do metano na atmosfera'
    ]
  },
  {
    name: 'Netuno',
    image: 'https://images.pexels.com/photos/816608/pexels-photo-816608.jpeg?auto=compress&cs=tinysrgb&w=800',
    description: 'O planeta mais distante, Netuno tem os ventos mais fortes do Sistema Solar.',
    diameter: '49.528 km',
    distanceFromSun: '4,515 bilhões km',
    moons: 16,
    rotationPeriod: '16,1 horas',
    orbitalPeriod: '164,8 anos terrestres',
    gravity: '11,15 m/s²',
    atmosphere: '80% hidrogênio, 19% hélio, 1% metano',
    temperature: '-201°C',
    color: '#4B70DD',
    composition: 'Água, metano e amônia gelados',
    namedAfter: 'Deus romano dos mares',
    facts: [
      'Tem ventos de até 2.100 km/h',
      'Foi descoberto através de cálculos matemáticos',
      'Um ano netuniano dura 165 anos terrestres',
      'Sua maior lua, Tritão, orbita no sentido contrário',
      'É o planeta mais denso dos gigantes gasosos'
    ]
  }
]
