
import React, { useState, useEffect } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import { Link } from 'react-router-dom'
import { Sun, Moon, ChevronUp, BookOpen, Globe, Sparkles } from 'lucide-react'
import PlanetCard from '../components/PlanetCard'
import Navigation from '../components/Navigation'
import StarField from '../components/StarField'
import { planetsData } from '../data/planetsData'

const HomePage: React.FC = () => {
  const [isDarkMode, setIsDarkMode] = useState(true)
  const [showBackToTop, setShowBackToTop] = useState(false)
  const { scrollY } = useScroll()
  
  const y1 = useTransform(scrollY, [0, 1000], [0, -100])
  const y2 = useTransform(scrollY, [0, 1000], [0, -200])

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 500)
    }
    
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode)
    document.documentElement.classList.toggle('light')
  }

  return (
    <div className={`min-h-screen transition-colors duration-500 ${isDarkMode ? 'bg-black text-white' : 'bg-gray-50 text-gray-900'}`}>
      {/* Star Field Background */}
      <StarField isDarkMode={isDarkMode} />
      
      {/* Navigation */}
      <Navigation isDarkMode={isDarkMode} />

      {/* Theme Toggle */}
      <motion.button
        onClick={toggleTheme}
        className={`fixed top-6 right-6 z-50 p-3 rounded-full backdrop-blur-md transition-all duration-300 ${
          isDarkMode 
            ? 'bg-white/10 hover:bg-white/20 border border-white/20' 
            : 'bg-black/10 hover:bg-black/20 border border-black/20'
        }`}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        aria-label="Alternar tema"
      >
        {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
      </motion.button>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-6">
        <motion.div 
          style={{ y: y1 }}
          className="text-center z-10"
        >
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="mb-8"
          >
            <Sparkles className="w-12 h-12 mx-auto mb-4 text-blue-400" />
            <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-6">
              Universo Geométrico
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Explore o Sistema Solar com design moderno e interativo. 
              Descubra planetas, suas características e curiosidades em uma experiência única.
            </p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            <Link 
              to="/todos-planetas"
              className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full font-semibold hover:from-blue-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 flex items-center gap-2"
            >
              <Globe className="w-5 h-5" />
              Explorar Planetas
            </Link>
            <Link 
              to="/modo-estudo"
              className={`px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105 flex items-center gap-2 ${
                isDarkMode 
                  ? 'bg-white/10 hover:bg-white/20 border border-white/20' 
                  : 'bg-black/10 hover:bg-black/20 border border-black/20'
              }`}
            >
              <BookOpen className="w-5 h-5" />
              Modo Estudo
            </Link>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center"
          >
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-1 h-3 bg-white/50 rounded-full mt-2"
            />
          </motion.div>
        </motion.div>
      </section>

      {/* Planets Section */}
      <section id="planetas" className="relative py-20 px-6">
        <motion.div 
          style={{ y: y2 }}
          className="max-w-7xl mx-auto"
        >
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-6xl font-bold mb-6">
              Nosso Sistema Solar
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Descubra os oito planetas que orbitam nossa estrela, cada um com suas características únicas e fascinantes.
            </p>
          </motion.div>

          {/* Planets Grid - Layout corrigido */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 lg:gap-8">
            {planetsData.map((planet, index) => (
              <motion.div
                key={planet.name}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="flex justify-center"
              >
                <PlanetCard planet={planet} isDarkMode={isDarkMode} />
              </motion.div>
            ))}
          </div>

          {/* Solar System Order Info */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            viewport={{ once: true }}
            className="mt-16 text-center"
          >
            <div className="bg-white/5 backdrop-blur-md rounded-2xl p-8 border border-white/10 max-w-4xl mx-auto">
              <h3 className="text-2xl font-bold mb-4">Ordem dos Planetas</h3>
              <p className="text-gray-300 leading-relaxed mb-6">
                Os planetas estão organizados por ordem de distância do Sol: 
                <span className="text-blue-400 font-semibold"> Mercúrio, Vênus, Terra, Marte</span> (planetas rochosos) e 
                <span className="text-purple-400 font-semibold"> Júpiter, Saturno, Urano, Netuno</span> (gigantes gasosos).
              </p>
              
              {/* Planet Distance Scale */}
              <div className="flex items-center justify-center space-x-1 sm:space-x-2 mt-6">
                <div className="w-3 h-3 bg-yellow-500 rounded-full" title="Sol"></div>
                {planetsData.map((planet) => (
                  <div key={planet.name} className="flex items-center">
                    <div className="w-1 h-px bg-gray-600 sm:w-4"></div>
                    <div 
                      className="w-2 h-2 rounded-full border border-white/30"
                      style={{ backgroundColor: planet.color }}
                      title={planet.name}
                    ></div>
                  </div>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-2">Escala representativa das distâncias</p>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* Back to Top Button */}
      {showBackToTop && (
        <motion.button
          onClick={scrollToTop}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0 }}
          className={`fixed bottom-8 right-8 p-4 rounded-full backdrop-blur-md transition-all duration-300 z-50 ${
            isDarkMode 
              ? 'bg-white/10 hover:bg-white/20 border border-white/20' 
              : 'bg-black/10 hover:bg-black/20 border border-black/20'
          }`}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          aria-label="Voltar ao topo"
        >
          <ChevronUp className="w-6 h-6" />
        </motion.button>
      )}
    </div>
  )
}

export default HomePage
