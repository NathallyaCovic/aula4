
import React from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { ArrowLeft, ExternalLink } from 'lucide-react'
import { planetsData } from '../data/planetsData'
import Navigation from '../components/Navigation'
import StarField from '../components/StarField'

const AllPlanetsPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-black text-white">
      <StarField isDarkMode={true} />
      <Navigation isDarkMode={true} />

      <div className="relative pt-24 pb-16 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors duration-200 mb-8"
            >
              <ArrowLeft className="w-5 h-5" />
              Voltar ao Sistema Solar
            </Link>

            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              Todos os Planetas
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Explore todos os oito planetas do nosso Sistema Solar. 
              Clique em qualquer planeta para descobrir suas características únicas.
            </p>
          </motion.div>

          {/* Planets Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {planetsData.map((planet, index) => (
              <motion.div
                key={planet.name}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Link
                  to={`/planeta/${planet.name.toLowerCase()}`}
                  className="group block"
                >
                  <motion.div
                    className="bg-white/5 backdrop-blur-md rounded-2xl overflow-hidden border border-white/10 hover:bg-white/10 transition-all duration-500"
                    whileHover={{ y: -10, scale: 1.02 }}
                  >
                    {/* Planet Image */}
                    <div className="relative h-64 overflow-hidden">
                      <motion.img
                        src={planet.image}
                        alt={`Planeta ${planet.name}`}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        animate={{ rotate: 360 }}
                        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                      />
                      
                      {/* Gradient Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      
                      {/* Planet Name */}
                      <div className="absolute bottom-4 left-4">
                        <h3 className="text-2xl font-bold text-white mb-1">{planet.name}</h3>
                        <div 
                          className="w-8 h-1 rounded-full"
                          style={{ backgroundColor: planet.color }}
                        />
                      </div>

                      {/* External Link Icon */}
                      <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <ExternalLink className="w-5 h-5 text-white" />
                      </div>
                    </div>

                    {/* Content */}
                    <div className="p-6">
                      <p className="text-gray-300 text-sm leading-relaxed mb-4">
                        {planet.description}
                      </p>

                      {/* Quick Stats */}
                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div>
                          <span className="text-gray-400">Diâmetro:</span>
                          <div className="font-semibold">{planet.diameter}</div>
                        </div>
                        <div>
                          <span className="text-gray-400">Luas:</span>
                          <div className="font-semibold">{planet.moons}</div>
                        </div>
                        <div>
                          <span className="text-gray-400">Distância:</span>
                          <div className="font-semibold text-xs">{planet.distanceFromSun}</div>
                        </div>
                        <div>
                          <span className="text-gray-400">Rotação:</span>
                          <div className="font-semibold text-xs">{planet.rotationPeriod}</div>
                        </div>
                      </div>
                    </div>

                    {/* Hover Effect */}
                    <motion.div
                      className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      style={{
                        background: `radial-gradient(circle at center, ${planet.color}10 0%, transparent 70%)`
                      }}
                    />
                  </motion.div>
                </Link>
              </motion.div>
            ))}
          </div>

          {/* Additional Info */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1 }}
            className="mt-16 text-center"
          >
            <div className="bg-white/5 backdrop-blur-md rounded-2xl p-8 border border-white/10 max-w-4xl mx-auto">
              <h3 className="text-2xl font-bold mb-4">Sobre o Sistema Solar</h3>
              <p className="text-gray-300 leading-relaxed">
                Nosso Sistema Solar é composto por oito planetas que orbitam o Sol. 
                Cada planeta tem características únicas, desde os pequenos e rochosos planetas internos 
                até os gigantes gasosos externos. Clique em qualquer planeta acima para explorar 
                suas características detalhadas, curiosidades e dados técnicos.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}

export default AllPlanetsPage
