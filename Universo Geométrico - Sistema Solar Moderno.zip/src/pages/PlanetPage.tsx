
import React from 'react'
import { useParams, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, ChevronLeft, ChevronRight, Globe, Thermometer, Clock, Ruler } from 'lucide-react'
import { planetsData } from '../data/planetsData'
import Navigation from '../components/Navigation'
import StarField from '../components/StarField'

const PlanetPage: React.FC = () => {
  const { planetName } = useParams<{ planetName: string }>()
  const planet = planetsData.find(p => p.name.toLowerCase() === planetName?.toLowerCase())
  
  if (!planet) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Planeta não encontrado</h1>
          <Link to="/" className="text-blue-400 hover:text-blue-300">
            Voltar à página inicial
          </Link>
        </div>
      </div>
    )
  }

  const currentIndex = planetsData.findIndex(p => p.name === planet.name)
  const previousPlanet = currentIndex > 0 ? planetsData[currentIndex - 1] : null
  const nextPlanet = currentIndex < planetsData.length - 1 ? planetsData[currentIndex + 1] : null

  return (
    <div className="min-h-screen bg-black text-white">
      <StarField isDarkMode={true} />
      <Navigation isDarkMode={true} />

      <div className="relative pt-24 pb-16 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Back Button */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-8"
          >
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors duration-200"
            >
              <ArrowLeft className="w-5 h-5" />
              Voltar ao Sistema Solar
            </Link>
          </motion.div>

          {/* Planet Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <div className="relative inline-block mb-8">
              <motion.img
                src={planet.image}
                alt={planet.name}
                className="w-64 h-64 md:w-80 md:h-80 rounded-full object-cover mx-auto shadow-2xl"
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              />
              <div
                className="absolute inset-0 rounded-full opacity-30 animate-pulse"
                style={{ 
                  boxShadow: `0 0 100px 20px ${planet.color}40` 
                }}
              />
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-4">
              {planet.name}
            </h1>
            <div 
              className="w-16 h-1 rounded-full mx-auto mb-6"
              style={{ backgroundColor: planet.color }}
            />
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              {planet.description}
            </p>
          </motion.div>

          {/* Technical Data Grid */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16"
          >
            <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
              <div className="flex items-center gap-3 mb-4">
                <Ruler className="w-6 h-6 text-blue-400" />
                <h3 className="text-lg font-semibold">Diâmetro</h3>
              </div>
              <p className="text-2xl font-bold" style={{ color: planet.color }}>
                {planet.diameter}
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
              <div className="flex items-center gap-3 mb-4">
                <Globe className="w-6 h-6 text-green-400" />
                <h3 className="text-lg font-semibold">Distância do Sol</h3>
              </div>
              <p className="text-2xl font-bold" style={{ color: planet.color }}>
                {planet.distanceFromSun}
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="w-6 h-6 text-yellow-400" />
                <h3 className="text-lg font-semibold">Período de Rotação</h3>
              </div>
              <p className="text-2xl font-bold" style={{ color: planet.color }}>
                {planet.rotationPeriod}
              </p>
            </div>

            <div className="bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10">
              <div className="flex items-center gap-3 mb-4">
                <Thermometer className="w-6 h-6 text-red-400" />
                <h3 className="text-lg font-semibold">Temperatura</h3>
              </div>
              <p className="text-2xl font-bold" style={{ color: planet.color }}>
                {planet.temperature}
              </p>
            </div>
          </motion.div>

          {/* Detailed Information */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16"
          >
            {/* Technical Specs */}
            <div className="bg-white/5 backdrop-blur-md rounded-2xl p-8 border border-white/10">
              <h3 className="text-2xl font-bold mb-6">Especificações Técnicas</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b border-white/10">
                  <span className="text-gray-400">Período Orbital:</span>
                  <span className="font-semibold">{planet.orbitalPeriod}</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-white/10">
                  <span className="text-gray-400">Gravidade:</span>
                  <span className="font-semibold">{planet.gravity}</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-white/10">
                  <span className="text-gray-400">Luas:</span>
                  <span className="font-semibold">{planet.moons}</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-white/10">
                  <span className="text-gray-400">Atmosfera:</span>
                  <span className="font-semibold">{planet.atmosphere}</span>
                </div>
                <div className="flex justify-between items-center py-3">
                  <span className="text-gray-400">Composição:</span>
                  <span className="font-semibold">{planet.composition}</span>
                </div>
              </div>
            </div>

            {/* Fun Facts */}
            <div className="bg-white/5 backdrop-blur-md rounded-2xl p-8 border border-white/10">
              <h3 className="text-2xl font-bold mb-6">Curiosidades</h3>
              <div className="space-y-4">
                {planet.facts.map((fact, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    className="flex items-start gap-3 p-4 rounded-lg bg-white/5"
                  >
                    <div 
                      className="w-2 h-2 rounded-full mt-2 flex-shrink-0"
                      style={{ backgroundColor: planet.color }}
                    />
                    <p className="text-gray-300 leading-relaxed">{fact}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Navigation Between Planets */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="flex justify-between items-center"
          >
            {previousPlanet ? (
              <Link
                to={`/planeta/${previousPlanet.name.toLowerCase()}`}
                className="flex items-center gap-3 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-300 group"
              >
                <ChevronLeft className="w-6 h-6 group-hover:-translate-x-1 transition-transform duration-200" />
                <div>
                  <p className="text-sm text-gray-400">Anterior</p>
                  <p className="text-lg font-semibold">{previousPlanet.name}</p>
                </div>
              </Link>
            ) : (
              <div />
            )}

            {nextPlanet ? (
              <Link
                to={`/planeta/${nextPlanet.name.toLowerCase()}`}
                className="flex items-center gap-3 bg-white/5 backdrop-blur-md rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-300 group"
              >
                <div className="text-right">
                  <p className="text-sm text-gray-400">Próximo</p>
                  <p className="text-lg font-semibold">{nextPlanet.name}</p>
                </div>
                <ChevronRight className="w-6 h-6 group-hover:translate-x-1 transition-transform duration-200" />
              </Link>
            ) : (
              <div />
            )}
          </motion.div>
        </div>
      </div>
    </div>
  )
}

export default PlanetPage
