
import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { ArrowLeft, BookOpen, Brain, Award, ChevronRight } from 'lucide-react'
import Navigation from '../components/Navigation'
import StarField from '../components/StarField'
import { planetsData } from '../data/planetsData'

const StudyModePage: React.FC = () => {
  const [currentQuiz, setCurrentQuiz] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [score, setScore] = useState(0)

  const quizQuestions = [
    {
      question: "Qual é o planeta mais próximo do Sol?",
      options: ["Vênus", "Mercúrio", "Terra", "Marte"],
      correct: 1,
      explanation: "Mercúrio é o planeta mais próximo do Sol, a apenas 57,9 milhões de km de distância."
    },
    {
      question: "Qual planeta tem os ventos mais fortes do Sistema Solar?",
      options: ["Júpiter", "Saturno", "Urano", "Netuno"],
      correct: 3,
      explanation: "Netuno tem ventos que podem chegar a 2.100 km/h, os mais fortes do Sistema Solar."
    },
    {
      question: "Quantas luas tem Saturno?",
      options: ["82", "95", "146", "27"],
      correct: 2,
      explanation: "Saturno tem 146 luas conhecidas, incluindo Titã, que é maior que Mercúrio."
    }
  ]

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex)
  }

  const handleSubmitAnswer = () => {
    if (selectedAnswer === null) return
    
    setShowResult(true)
    if (selectedAnswer === quizQuestions[currentQuiz].correct) {
      setScore(score + 1)
    }
  }

  const handleNextQuestion = () => {
    if (currentQuiz < quizQuestions.length - 1) {
      setCurrentQuiz(currentQuiz + 1)
      setSelectedAnswer(null)
      setShowResult(false)
    }
  }

  const resetQuiz = () => {
    setCurrentQuiz(0)
    setSelectedAnswer(null)
    setShowResult(false)
    setScore(0)
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <StarField isDarkMode={true} />
      <Navigation isDarkMode={true} />

      <div className="relative pt-24 pb-16 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors duration-200 mb-8"
            >
              <ArrowLeft className="w-5 h-5" />
              Voltar ao Sistema Solar
            </Link>

            <div className="mb-8">
              <Brain className="w-16 h-16 mx-auto mb-4 text-purple-400" />
              <h1 className="text-5xl md:text-7xl font-bold mb-6">
                Modo Estudo
              </h1>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
                Teste seus conhecimentos sobre o Sistema Solar com nosso quiz interativo 
                e aprenda curiosidades fascinantes sobre os planetas.
              </p>
            </div>
          </motion.div>

          {/* Study Sections */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
            {/* Quiz Section */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white/5 backdrop-blur-md rounded-2xl p-8 border border-white/10"
            >
              <div className="flex items-center gap-3 mb-6">
                <BookOpen className="w-8 h-8 text-blue-400" />
                <h2 className="text-3xl font-bold">Quiz Interativo</h2>
              </div>

              {currentQuiz < quizQuestions.length ? (
                <div>
                  <div className="mb-6">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-sm text-gray-400">
                        Pergunta {currentQuiz + 1} de {quizQuestions.length}
                      </span>
                      <span className="text-sm text-gray-400">
                        Pontuação: {score}/{quizQuestions.length}
                      </span>
                    </div>
                    <div className="w-full bg-white/10 rounded-full h-2 mb-6">
                      <div 
                        className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${((currentQuiz + 1) / quizQuestions.length) * 100}%` }}
                      />
                    </div>
                  </div>

                  <h3 className="text-xl font-semibold mb-6">
                    {quizQuestions[currentQuiz].question}
                  </h3>

                  <div className="space-y-3 mb-6">
                    {quizQuestions[currentQuiz].options.map((option, index) => (
                      <button
                        key={index}
                        onClick={() => handleAnswerSelect(index)}
                        disabled={showResult}
                        className={`w-full p-4 rounded-lg border transition-all duration-200 text-left ${
                          selectedAnswer === index
                            ? showResult
                              ? index === quizQuestions[currentQuiz].correct
                                ? 'bg-green-500/20 border-green-500'
                                : 'bg-red-500/20 border-red-500'
                              : 'bg-blue-500/20 border-blue-500'
                            : showResult && index === quizQuestions[currentQuiz].correct
                              ? 'bg-green-500/20 border-green-500'
                              : 'bg-white/5 border-white/10 hover:bg-white/10'
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>

                  {showResult && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mb-6 p-4 rounded-lg bg-white/5"
                    >
                      <p className="text-gray-300">
                        {quizQuestions[currentQuiz].explanation}
                      </p>
                    </motion.div>
                  )}

                  <div className="flex gap-4">
                    {!showResult ? (
                      <button
                        onClick={handleSubmitAnswer}
                        disabled={selectedAnswer === null}
                        className="px-6 py-3 bg-blue-500 hover:bg-blue-600 disabled:bg-gray-600 disabled:cursor-not-allowed rounded-lg font-semibold transition-colors duration-200"
                      >
                        Confirmar Resposta
                      </button>
                    ) : (
                      <button
                        onClick={handleNextQuestion}
                        className="px-6 py-3 bg-green-500 hover:bg-green-600 rounded-lg font-semibold transition-colors duration-200 flex items-center gap-2"
                      >
                        Próxima Pergunta
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center"
                >
                  <Award className="w-16 h-16 mx-auto mb-4 text-yellow-400" />
                  <h3 className="text-2xl font-bold mb-4">Quiz Concluído!</h3>
                  <p className="text-xl mb-6">
                    Sua pontuação: {score}/{quizQuestions.length}
                  </p>
                  <button
                    onClick={resetQuiz}
                    className="px-6 py-3 bg-purple-500 hover:bg-purple-600 rounded-lg font-semibold transition-colors duration-200"
                  >
                    Fazer Quiz Novamente
                  </button>
                </motion.div>
              )}
            </motion.div>

            {/* Planet Comparison */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white/5 backdrop-blur-md rounded-2xl p-8 border border-white/10"
            >
              <h2 className="text-3xl font-bold mb-6">Comparação de Planetas</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-blue-400">Tamanho (Diâmetro)</h3>
                  <div className="space-y-2">
                    {planetsData
                      .sort((a, b) => parseInt(b.diameter.replace(/\D/g, '')) - parseInt(a.diameter.replace(/\D/g, '')))
                      .slice(0, 4)
                      .map((planet, index) => (
                        <div key={planet.name} className="flex items-center gap-3">
                          <div className="w-8 text-sm text-gray-400">{index + 1}º</div>
                          <div 
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: planet.color }}
                          />
                          <span className="flex-1">{planet.name}</span>
                          <span className="text-sm text-gray-400">{planet.diameter}</span>
                        </div>
                      ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-3 text-green-400">Número de Luas</h3>
                  <div className="space-y-2">
                    {planetsData
                      .sort((a, b) => b.moons - a.moons)
                      .slice(0, 4)
                      .map((planet, index) => (
                        <div key={planet.name} className="flex items-center gap-3">
                          <div className="w-8 text-sm text-gray-400">{index + 1}º</div>
                          <div 
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: planet.color }}
                          />
                          <span className="flex-1">{planet.name}</span>
                          <span className="text-sm text-gray-400">{planet.moons} luas</span>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Fun Facts Section */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-white/5 backdrop-blur-md rounded-2xl p-8 border border-white/10"
          >
            <h2 className="text-3xl font-bold mb-8 text-center">Curiosidades do Sistema Solar</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  title: "Júpiter é um Protetor",
                  description: "Júpiter atua como um 'aspirador de poeira cósmica', protegendo os planetas internos de asteroides e cometas.",
                  color: "#D8CA9D"
                },
                {
                  title: "Vênus Gira ao Contrário",
                  description: "Vênus é o único planeta que gira no sentido contrário aos outros planetas do Sistema Solar.",
                  color: "#FFC649"
                },
                {
                  title: "Saturno Flutuaria",
                  description: "Saturno é menos denso que a água. Se houvesse um oceano grande o suficiente, ele flutuaria!",
                  color: "#FAD5A5"
                },
                {
                  title: "Marte Tem Estações",
                  description: "Marte tem estações como a Terra devido à inclinação de seu eixo, mas cada estação dura cerca de 6 meses.",
                  color: "#CD5C5C"
                },
                {
                  title: "Urano Gira de Lado",
                  description: "Urano tem uma inclinação de 98 graus, fazendo com que ele literalmente gire de lado.",
                  color: "#4FD0E7"
                },
                {
                  title: "Netuno é Supersônico",
                  description: "Os ventos em Netuno podem chegar a 2.100 km/h, mais rápidos que a velocidade do som na Terra.",
                  color: "#4B70DD"
                }
              ].map((fact, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 + index * 0.1 }}
                  className="bg-white/5 rounded-xl p-6 border border-white/10"
                >
                  <div 
                    className="w-12 h-12 rounded-full mb-4 flex items-center justify-center"
                    style={{ backgroundColor: `${fact.color}20` }}
                  >
                    <div 
                      className="w-6 h-6 rounded-full"
                      style={{ backgroundColor: fact.color }}
                    />
                  </div>
                  <h3 className="text-lg font-semibold mb-3">{fact.title}</h3>
                  <p className="text-gray-300 text-sm leading-relaxed">{fact.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}

export default StudyModePage
