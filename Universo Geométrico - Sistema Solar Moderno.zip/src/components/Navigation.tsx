
import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Link, useLocation } from 'react-router-dom'
import { Menu, X, Sparkles } from 'lucide-react'
import { planetsData } from '../data/planetsData'

interface NavigationProps {
  isDarkMode: boolean
}

const Navigation: React.FC<NavigationProps> = ({ isDarkMode }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToPlanet = (planetName: string) => {
    if (location.pathname === '/') {
      const element = document.getElementById(planetName.toLowerCase())
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' })
      }
    }
    setIsMenuOpen(false)
  }

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'backdrop-blur-md bg-black/20 border-b border-white/10' 
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 text-xl font-bold">
            <Sparkles className="w-6 h-6 text-blue-400" />
            <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Universo Geométrico
            </span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden lg:flex items-center gap-8">
            <div className="flex items-center gap-6">
              {planetsData.slice(0, 4).map((planet) => (
                <Link
                  key={planet.name}
                  to={`/planeta/${planet.name.toLowerCase()}`}
                  className="text-sm font-medium hover:text-blue-400 transition-colors duration-200"
                >
                  {planet.name}
                </Link>
              ))}
            </div>
            
            <div className="w-px h-6 bg-white/20" />
            
            <div className="flex items-center gap-6">
              {planetsData.slice(4).map((planet) => (
                <Link
                  key={planet.name}
                  to={`/planeta/${planet.name.toLowerCase()}`}
                  className="text-sm font-medium hover:text-blue-400 transition-colors duration-200"
                >
                  {planet.name}
                </Link>
              ))}
            </div>

            <div className="w-px h-6 bg-white/20" />

            <div className="flex items-center gap-6">
              <Link
                to="/modo-estudo"
                className="text-sm font-medium hover:text-blue-400 transition-colors duration-200"
              >
                Modo Estudo
              </Link>
              <Link
                to="/todos-planetas"
                className="text-sm font-medium hover:text-blue-400 transition-colors duration-200"
              >
                Todos os Planetas
              </Link>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="lg:hidden p-2 rounded-lg hover:bg-white/10 transition-colors duration-200"
            aria-label="Menu"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden mt-4 py-4 border-t border-white/10"
          >
            <div className="flex flex-col gap-4">
              <div className="text-sm font-semibold text-gray-400 uppercase tracking-wider">
                Planetas
              </div>
              {planetsData.map((planet) => (
                <Link
                  key={planet.name}
                  to={`/planeta/${planet.name.toLowerCase()}`}
                  onClick={() => setIsMenuOpen(false)}
                  className="text-sm font-medium hover:text-blue-400 transition-colors duration-200 pl-4"
                >
                  {planet.name}
                </Link>
              ))}
              
              <div className="border-t border-white/10 pt-4 mt-4">
                <Link
                  to="/modo-estudo"
                  onClick={() => setIsMenuOpen(false)}
                  className="block text-sm font-medium hover:text-blue-400 transition-colors duration-200 mb-2"
                >
                  Modo Estudo
                </Link>
                <Link
                  to="/todos-planetas"
                  onClick={() => setIsMenuOpen(false)}
                  className="block text-sm font-medium hover:text-blue-400 transition-colors duration-200"
                >
                  Todos os Planetas
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </motion.nav>
  )
}

export default Navigation
