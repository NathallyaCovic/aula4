
import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { ExternalLink, Info } from 'lucide-react'

interface Planet {
  name: string
  image: string
  description: string
  diameter: string
  distanceFromSun: string
  moons: number
  rotationPeriod: string
  color: string
  facts: string[]
}

interface PlanetCardProps {
  planet: Planet
  isDarkMode: boolean
}

const PlanetCard: React.FC<PlanetCardProps> = ({ planet, isDarkMode }) => {
  const [showTooltip, setShowTooltip] = useState(false)

  return (
    <motion.div
      className={`relative group rounded-2xl overflow-hidden backdrop-blur-md transition-all duration-500 ${
        isDarkMode 
          ? 'bg-white/5 border border-white/10 hover:bg-white/10' 
          : 'bg-black/5 border border-black/10 hover:bg-black/10'
      }`}
      whileHover={{ y: -10, scale: 1.02 }}
      onHoverStart={() => setShowTooltip(true)}
      onHoverEnd={() => setShowTooltip(false)}
    >
      {/* Planet Image */}
      <div className="relative h-64 overflow-hidden">
        <motion.img
          src={planet.image}
          alt={`Planeta ${planet.name}`}
          className="w-full h-full object-cover"
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        />
        
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        
        {/* Planet Name */}
        <div className="absolute bottom-4 left-4">
          <h3 className="text-2xl font-bold text-white mb-1">{planet.name}</h3>
          <div 
            className="w-8 h-1 rounded-full"
            style={{ backgroundColor: planet.color }}
          />
        </div>

        {/* Info Button */}
        <button
          className="absolute top-4 right-4 p-2 rounded-full bg-black/30 backdrop-blur-sm hover:bg-black/50 transition-colors duration-200"
          onMouseEnter={() => setShowTooltip(true)}
          onMouseLeave={() => setShowTooltip(false)}
        >
          <Info className="w-4 h-4 text-white" />
        </button>
      </div>

      {/* Content */}
      <div className="p-6">
        <p className="text-gray-300 text-sm leading-relaxed mb-4">
          {planet.description}
        </p>

        {/* Quick Facts */}
        <div className="grid grid-cols-2 gap-3 mb-4 text-xs">
          <div>
            <span className="text-gray-400">Diâmetro:</span>
            <div className="font-semibold">{planet.diameter}</div>
          </div>
          <div>
            <span className="text-gray-400">Luas:</span>
            <div className="font-semibold">{planet.moons}</div>
          </div>
        </div>

        {/* Link to Planet Page */}
        <Link
          to={`/planeta/${planet.name.toLowerCase()}`}
          className="inline-flex items-center gap-2 text-sm font-medium text-blue-400 hover:text-blue-300 transition-colors duration-200"
        >
          Explorar {planet.name}
          <ExternalLink className="w-4 h-4" />
        </Link>
      </div>

      {/* Tooltip */}
      {showTooltip && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10 }}
          className="absolute -top-2 left-1/2 transform -translate-x-1/2 -translate-y-full z-20"
        >
          <div className="bg-black/90 backdrop-blur-md rounded-lg p-4 border border-white/20 min-w-64">
            <div className="text-sm space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Distância do Sol:</span>
                <span className="font-semibold">{planet.distanceFromSun}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Período de Rotação:</span>
                <span className="font-semibold">{planet.rotationPeriod}</span>
              </div>
              <div className="pt-2 border-t border-white/20">
                <span className="text-gray-400 text-xs">Curiosidade:</span>
                <p className="text-xs mt-1">{planet.facts[0]}</p>
              </div>
            </div>
            
            {/* Tooltip Arrow */}
            <div className="absolute top-full left-1/2 transform -translate-x-1/2">
              <div className="w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black/90" />
            </div>
          </div>
        </motion.div>
      )}

      {/* Orbital Animation */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        animate={{ rotate: 360 }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
      >
        <div 
          className="absolute top-2 left-2 w-2 h-2 rounded-full opacity-30"
          style={{ backgroundColor: planet.color }}
        />
      </motion.div>
    </motion.div>
  )
}

export default PlanetCard
