
import React, { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'

interface StarFieldProps {
  isDarkMode: boolean
}

const StarField: React.FC<StarFieldProps> = ({ isDarkMode }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    resizeCanvas()
    window.addEventListener('resize', resizeCanvas)

    // Create stars
    const stars: Array<{
      x: number
      y: number
      size: number
      opacity: number
      speed: number
      color: string
    }> = []

    for (let i = 0; i < 200; i++) {
      stars.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.8 + 0.2,
        speed: Math.random() * 0.5 + 0.1,
        color: ['#ffffff', '#b3d9ff', '#ffeb99', '#ffb3ba'][Math.floor(Math.random() * 4)]
      })
    }

    let animationId: number

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw stars
      stars.forEach((star) => {
        ctx.beginPath()
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2)
        ctx.fillStyle = star.color
        ctx.globalAlpha = star.opacity
        ctx.fill()

        // Twinkle effect
        star.opacity += (Math.random() - 0.5) * 0.02
        star.opacity = Math.max(0.1, Math.min(1, star.opacity))

        // Slow movement
        star.y += star.speed
        if (star.y > canvas.height) {
          star.y = -star.size
          star.x = Math.random() * canvas.width
        }
      })

      ctx.globalAlpha = 1
      animationId = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener('resize', resizeCanvas)
      cancelAnimationFrame(animationId)
    }
  }, [])

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {/* Animated canvas stars */}
      <canvas
        ref={canvasRef}
        className={`absolute inset-0 transition-opacity duration-500 ${
          isDarkMode ? 'opacity-100' : 'opacity-30'
        }`}
      />

      {/* Nebula effects */}
      <motion.div
        animate={{
          background: [
            'radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.1) 0%, transparent 50%)',
            'radial-gradient(circle at 40% 40%, rgba(119, 198, 255, 0.1) 0%, transparent 50%)'
          ]
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          repeatType: 'reverse'
        }}
        className={`absolute inset-0 transition-opacity duration-500 ${
          isDarkMode ? 'opacity-100' : 'opacity-20'
        }`}
      />

      {/* Additional nebula layers */}
      <motion.div
        animate={{
          background: [
            'radial-gradient(circle at 60% 70%, rgba(198, 119, 255, 0.05) 0%, transparent 60%)',
            'radial-gradient(circle at 30% 30%, rgba(119, 255, 198, 0.05) 0%, transparent 60%)'
          ]
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          repeatType: 'reverse',
          delay: 5
        }}
        className={`absolute inset-0 transition-opacity duration-500 ${
          isDarkMode ? 'opacity-100' : 'opacity-10'
        }`}
      />
    </div>
  )
}

export default StarField
